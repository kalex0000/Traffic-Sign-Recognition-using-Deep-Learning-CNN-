import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cv2
import os
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPool2D, Dense, Flatten, Dropout
from tensorflow.keras.optimizers import Adam

# ===================== LOAD TRAIN DATA =====================

data = []
labels = []
classes = 43
cur_path = os.getcwd()

print("Loading Training Images...")

for i in range(classes):
    path = os.path.join(cur_path,'Train',str(i))
    images = os.listdir(path)

    for a in images:
        try:
            image = cv2.imread(path + '/' + a)
            image = cv2.resize(image,(32,32))
            data.append(image)
            labels.append(i)
        except:
            print("Error loading image")

data = np.array(data)
labels = np.array(labels)

# ===================== SPLIT =====================

X_train, X_test, y_train, y_test = train_test_split(
data, labels, test_size=0.2, random_state=42)

X_train = X_train/255.0
X_test = X_test/255.0

y_train = to_categorical(y_train,43)
y_test = to_categorical(y_test,43)

# ===================== CNN MODEL =====================

model = Sequential()

model.add(Conv2D(32,(5,5),activation='relu',
input_shape=X_train.shape[1:]))
model.add(MaxPool2D((2,2)))

model.add(Conv2D(64,(3,3),activation='relu'))
model.add(MaxPool2D((2,2)))

model.add(Flatten())

model.add(Dense(256,activation='relu'))
model.add(Dropout(0.5))

model.add(Dense(43,activation='softmax'))

# ===================== COMPILE =====================

model.compile(
loss='categorical_crossentropy',
optimizer=Adam(learning_rate=0.001),
metrics=['accuracy']
)

# ===================== TRAIN =====================

print("Training Started...")

history = model.fit(
X_train,y_train,
batch_size=32,
epochs=15,
validation_data=(X_test,y_test)
)

# ===================== ACCURACY GRAPH =====================

plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Model Accuracy')
plt.legend(['Train','Validation'])
plt.savefig("accuracy.png")
plt.close()

# ===================== LOSS GRAPH =====================

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model Loss')
plt.legend(['Train','Validation'])
plt.savefig("loss.png")
plt.close()

# ===================== CONFUSION MATRIX =====================

from sklearn.metrics import confusion_matrix
import seaborn as sns

y_pred = model.predict(X_test)
y_pred_classes = np.argmax(y_pred,axis=1)
y_true = np.argmax(y_test,axis=1)

cm = confusion_matrix(y_true,y_pred_classes)

plt.figure(figsize=(10,7))
sns.heatmap(cm)
plt.title("Confusion Matrix")
plt.savefig("confusion_matrix.png")
plt.close()

# ===================== SAVE MODEL =====================

model.save("traffic_sign_model.h5")

# ===================== TEST ON UNSEEN DATA =====================

print("Testing on Unseen Data...")

test = pd.read_csv('Test.csv')

labels = test["ClassId"].values
imgs = test["Path"].values

data=[]

for img in imgs:
    filename = img.split('/')[-1]
    img_path = os.path.join(cur_path, "Test", filename)

    image = cv2.imread(img_path)
    if image is None:
        continue

    image = cv2.resize(image,(32,32))
    data.append(image)

X_test=np.array(data)/255.0

pred = model.predict(X_test)
pred_classes = np.argmax(pred,axis=1)

from sklearn.metrics import accuracy_score
print("Final Test Accuracy:",
      accuracy_score(labels[:len(pred_classes)],pred_classes))